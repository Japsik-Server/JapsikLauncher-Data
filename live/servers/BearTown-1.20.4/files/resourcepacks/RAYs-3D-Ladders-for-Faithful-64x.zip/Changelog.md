# RAY's 3D Ladders Changelog

## 1.1

### Added:
- Speedy Ladders Support
- LICENSE

### Fixed:
- Particle Mossy Ladder issue
- Removed unnecessary item textures

### Changed:
- New texture for all vanilla based ladders
- New pack.mcmeta description
- New pack.png

*****
## 1.0

### Added:
- Vanilla Support
- Chipped Support